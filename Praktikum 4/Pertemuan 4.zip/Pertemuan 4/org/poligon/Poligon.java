/**
 * File : Poligon.java 15/03/2023
 * Penulis : Fauzan Ramadhan Putra (24060121140140)
 * Deskripsi : representasi dasar dari objek poligon
 */
 
 package org.poligon;
 
 public class Poligon{
	 protected int jumlahSisi;
	 
	 public void setJumlahSisi(int sisi){
		 this.jumlahSisi = sisi;
	 }
	 
	 public int getJumlahSisi(){
		 return this.jumlahSisi;
	 }
 }